﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LapTimeManager : MonoBehaviour {

    Text lapTimeText;
    public float lapTime = 0.0f;
    string lapTimeString;
    bool lapComplete = false;
    public BoxCollider finishLine;

    void Awake()
    {
        lapTimeText = GetComponent<Text>();
        finishLine.GetComponent<BoxCollider>();
    }

    void OnTriggerEnter(Collider collider)
    {
        if (collider.gameObject.name == "Player")
        {
            lapComplete = true;
        }
    }

    public string FormatLapTime(float lapTimer)
    {
        string lapTimerString = lapTimer.ToString();
        lapTimerString = string.Format("{0}:{1:00}", (int)lapTimer / 60, (int)lapTimer % 60);

        return lapTimerString;
    }

    IEnumerator LapTime()
    {
        while (true)
        {
            if (lapComplete == false)
            {
                lapTimeString = FormatLapTime(lapTime);
                lapTimeText.text = lapTimeString;
            }
            else
            {
                if (lapTime > PlayerPrefs.GetFloat("BestLapTime_1"))
                {
                    PlayerPrefs.SetFloat("BestLapTime_1", lapTime);
                }
            }

            yield return new WaitForSeconds(1);
            lapTime++;
        }
    }
}
