﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerSpawner : MonoBehaviour {
	public GameObject player;
	public Transform[] spawnPoints;

	// Use this for initialization
	void Start () {
		spawnPlayers ();
	}

	void spawnPlayers ()
	{
		int spawnPointIndex = Random.Range (0, spawnPoints.Length);
		Instantiate (player, spawnPoints[spawnPointIndex].position, spawnPoints[spawnPointIndex].rotation);
	}
}
