﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerSpawner : MonoBehaviour {
	public GameObject player;
	public Transform[] spawnPoints;
	private int playerNumber;
	private int countPlayer = 0;
	private int countPlayerNumber = 1;
	private int camNumber = 0;
	private int countCamNumber = 1;
	private int setCamNumCount= 0;

	//public int setPlayerNumber;
	// Use this for initialization
	void Start () {
		spawnPlayers ();
	}

	void spawnPlayers ()
	{
		
		for (var i = 0; i < 4; i++) {
			Instantiate (player, spawnPoints [countPlayer].position, spawnPoints [countPlayer].rotation);
			countPlayer++;

		}
	}

	public int setPlayerNumber()
	{
		playerNumber = countPlayerNumber++;
		return playerNumber;
	}

	public int setCamNumber()
	{
		camNumber = countCamNumber++;
		return camNumber;
	}

	public int setCamRectNumber()
	{
		setCamNumCount++;
		return setCamNumCount;
	}
}
